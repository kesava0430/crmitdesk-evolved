import { useSearchParams } from 'react-router-dom';
import { CreditCard, CheckCircle, Zap, Building2, Star, ExternalLink, AlertCircle } from 'lucide-react';
import { useSubscription, useCreateCheckout, useCreatePortal } from '../api/billing';
import { Spinner } from '../shared/components';
import { useFormat } from '../hooks/useFormat';

const PLAN_ICONS = { FREE: Star, PRO: Zap, ENTERPRISE: Building2 };
const PLAN_COLORS = {
  FREE: { bg: 'bg-surface-sunken', border: 'border-line', badge: 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300', btn: 'bg-gray-200 text-gray-500 cursor-not-allowed dark:bg-gray-700 dark:text-gray-500' },
  PRO: { bg: 'bg-violet-50 dark:bg-violet-500/10', border: 'border-violet-300 dark:border-violet-500/30', badge: 'bg-violet-100 text-violet-700 dark:bg-violet-500/20 dark:text-violet-300', btn: 'bg-brand-600 text-white hover:bg-brand-700' },
  ENTERPRISE: { bg: 'bg-blue-50 dark:bg-blue-500/10', border: 'border-blue-300 dark:border-blue-500/30', badge: 'bg-blue-100 text-blue-700 dark:bg-blue-500/20 dark:text-blue-300', btn: 'bg-blue-600 text-white hover:bg-blue-700' },
};

const FEATURES: Record<string, string[]> = {
  FREE:       ['5 billable seats (Employees are unlimited)', 'CRM + IT Desk', 'Email notifications', 'AI features (limited)', 'Attachments via your own Google Drive', 'Community support'],
  PRO:        ['25 billable seats (Employees are unlimited)', 'Everything in Free', 'Unlimited inbox messages', 'Workflow automation', 'Customer portal', 'Advanced analytics', '5GB hosted attachment storage (or keep using your own Drive)', 'Priority support'],
  ENTERPRISE: ['Unlimited billable seats', 'Everything in Pro', 'SSO / SAML', 'Custom branding', '50GB hosted attachment storage', 'SLA guarantees', 'Dedicated account manager'],
};

export function BillingPage() {
  const { date, timezone } = useFormat();
  const monthDay = (v: string) => new Intl.DateTimeFormat(undefined, { timeZone: timezone, month: 'short', day: 'numeric' }).format(new Date(v));
  const [searchParams] = useSearchParams();
  const { data: sub, isLoading } = useSubscription();
  const checkout = useCreateCheckout();
  const portal = useCreatePortal();

  const success = searchParams.get('success') === '1';
  const canceled = searchParams.get('canceled') === '1';

  if (isLoading) return <div className="p-6 flex justify-center"><Spinner label="Loading billing…" /></div>;

  const current = sub?.plan || 'FREE';

  return (
    <div className="p-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <CreditCard size={20} className="text-brand-600" />
            <h1 className="text-xl font-bold text-fg">Billing & Plans</h1>
          </div>
          <p className="text-sm text-fg-muted">Manage your subscription and billing details.</p>
        </div>
        {sub?.stripeCustomerId && (
          <button onClick={() => portal.mutate()} disabled={portal.isPending}
            className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 rounded-xl text-sm font-medium hover:bg-gray-50 disabled:opacity-40 dark:border-gray-700 dark:hover:bg-gray-800 dark:text-gray-200">
            {portal.isPending ? <Spinner /> : <ExternalLink size={14} />}
            Manage billing
          </button>
        )}
      </div>

      {/* Flash messages */}
      {success && (
        <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 rounded-xl mb-6 dark:bg-green-500/10 dark:border-green-500/30">
          <CheckCircle size={18} className="text-green-600 flex-shrink-0 dark:text-green-400" />
          <p className="text-sm text-green-800 font-medium dark:text-green-300">Subscription updated successfully! Your plan is now active.</p>
        </div>
      )}
      {canceled && (
        <div className="flex items-center gap-3 p-4 bg-amber-50 border border-amber-200 rounded-xl mb-6 dark:bg-amber-500/10 dark:border-amber-500/30">
          <AlertCircle size={18} className="text-amber-600 flex-shrink-0 dark:text-amber-400" />
          <p className="text-sm text-amber-800 dark:text-amber-300">Checkout was cancelled. Your current plan is unchanged.</p>
        </div>
      )}

      {/* Current plan summary */}
      {sub && (
        <div className="bg-white border border-gray-200 rounded-2xl p-5 mb-8 dark:bg-gray-900 dark:border-gray-800">
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <p className="text-xs text-gray-500 mb-1 dark:text-gray-400">Current plan</p>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold text-fg">{sub.planConfig.name}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${sub.status === 'active' ? 'bg-green-50 text-green-700 dark:bg-green-500/10 dark:text-green-400' : 'bg-red-50 text-red-600 dark:bg-red-500/10 dark:text-red-400'}`}>
                  {sub.status}
                </span>
                {sub.cancelAtPeriodEnd && (
                  <span className="text-xs px-2 py-0.5 rounded-full bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-400">Cancels at period end</span>
                )}
              </div>
              <p className="text-sm text-gray-500 mt-1 dark:text-gray-400">{sub.seats} seats · {sub.planConfig.price > 0 ? `$${sub.planConfig.price}/mo` : 'Free forever'}</p>
            </div>
            {sub.currentPeriodEnd && (
              <div className="text-right">
                <p className="text-xs text-fg-subtle">Next billing date</p>
                <p className="text-sm font-medium text-fg">{date(sub.currentPeriodEnd)}</p>
              </div>
            )}
          </div>

          {/* Seat usage */}
          <div className="mt-4 pt-4 border-t border-line-subtle">
            <div className="flex items-center justify-between mb-1.5">
              <p className="text-xs font-medium text-fg-muted">Billable seats used</p>
              <p className={`text-xs font-semibold ${sub.seatsUsed >= sub.seats ? 'text-red-600 dark:text-red-400' : 'text-fg'}`}>
                {sub.seatsUsed} / {sub.seats}
              </p>
            </div>
            <div className="w-full h-2 bg-gray-100 rounded-full overflow-hidden dark:bg-gray-800">
              <div
                className={`h-full rounded-full transition-all ${sub.seatsUsed >= sub.seats ? 'bg-red-500' : sub.seatsUsed / sub.seats >= 0.8 ? 'bg-amber-400' : 'bg-brand-500'}`}
                style={{ width: `${Math.min(100, (sub.seatsUsed / sub.seats) * 100)}%` }}
              />
            </div>
            <p className="text-xs text-gray-400 mt-1.5 dark:text-gray-500">
              Every role counts except Employee — those logins are free and unlimited.
              {sub.seatsUsed >= sub.seats && ' You\'re at your limit; upgrade to add more people in a billable role.'}
            </p>
          </div>
        </div>
      )}

      {/* Usage this month — informational only, nothing here is billed or
          capped yet. Purely visibility until real limits get set. */}
      {sub && (
        <div className="bg-white border border-gray-200 rounded-2xl p-5 mb-8 dark:bg-gray-900 dark:border-gray-800">
          <p className="text-xs text-gray-500 mb-3 dark:text-gray-400">
            Usage this month <span className="text-fg-subtle">({monthDay(sub.usage.periodStart)} – {monthDay(sub.usage.periodEnd)})</span>
          </p>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-2xl font-bold text-fg">{sub.usage.aiCalls.toLocaleString()}</p>
              <p className="text-xs text-gray-500 mt-0.5 dark:text-gray-400">AI calls</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-fg">{sub.usage.whatsappSends.toLocaleString()}</p>
              <p className="text-xs text-gray-500 mt-0.5 dark:text-gray-400">WhatsApp messages sent</p>
            </div>
          </div>
          <p className="text-xs text-gray-400 mt-3 dark:text-gray-500">Not currently limited or billed separately — shown for visibility only.</p>
        </div>
      )}

      {/* Plan cards */}
      <h2 className="text-base font-semibold text-gray-900 mb-4 dark:text-white">Available Plans</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {(['FREE', 'PRO', 'ENTERPRISE'] as const).map(plan => {
          const isCurrent = plan === current;
          const colors = PLAN_COLORS[plan];
          const Icon = PLAN_ICONS[plan];
          const price = plan === 'FREE' ? 0 : plan === 'PRO' ? 49 : 149;

          return (
            <div key={plan}
              className={`relative rounded-2xl border-2 p-6 flex flex-col ${isCurrent ? `${colors.bg} ${colors.border}` : 'bg-white border-gray-200 dark:bg-gray-900 dark:border-gray-800'}`}>
              {isCurrent && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className={`text-xs font-semibold px-3 py-1 rounded-full ${colors.badge}`}>Current plan</span>
                </div>
              )}
              {plan === 'PRO' && !isCurrent && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="text-xs font-semibold px-3 py-1 rounded-full bg-brand-600 text-white">Most popular</span>
                </div>
              )}

              <div className="flex items-center gap-2 mb-3">
                <Icon size={18} className={plan === 'FREE' ? 'text-fg-subtle' : plan === 'PRO' ? 'text-brand-600' : 'text-blue-600'} />
                <h3 className="font-bold text-fg">{plan === 'FREE' ? 'Free' : plan === 'PRO' ? 'Pro' : 'Enterprise'}</h3>
              </div>

              <div className="mb-5">
                <span className="text-3xl font-bold text-fg">${price}</span>
                <span className="text-sm text-fg-subtle">/mo</span>
              </div>

              <ul className="space-y-2 flex-1 mb-6">
                {FEATURES[plan].map(f => (
                  <li key={f} className="flex items-center gap-2 text-sm text-fg-muted">
                    <CheckCircle size={13} className="text-green-500 flex-shrink-0" /> {f}
                  </li>
                ))}
              </ul>

              {isCurrent ? (
                <button disabled className="w-full py-2.5 rounded-xl text-sm font-medium bg-gray-100 text-gray-400 cursor-not-allowed dark:bg-gray-800 dark:text-gray-600">
                  Current plan
                </button>
              ) : plan === 'FREE' ? (
                <button disabled className="w-full py-2.5 rounded-xl text-sm font-medium bg-gray-100 text-gray-400 cursor-not-allowed dark:bg-gray-800 dark:text-gray-600">
                  Downgrade
                </button>
              ) : (
                <button onClick={() => checkout.mutate(plan)} disabled={checkout.isPending}
                  className={`w-full py-2.5 rounded-xl text-sm font-medium disabled:opacity-40 flex items-center justify-center gap-2 ${colors.btn}`}>
                  {checkout.isPending ? <Spinner /> : null}
                  Upgrade to {plan === 'PRO' ? 'Pro' : 'Enterprise'}
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* Stripe setup note */}
      {!sub?.stripeCustomerId && sub?.plan === 'FREE' && (
        <div className="mt-8 p-4 bg-amber-50 border border-amber-200 rounded-xl text-sm text-amber-800 dark:bg-amber-500/10 dark:border-amber-500/30 dark:text-amber-300">
          <p className="font-medium mb-1">Configure Stripe to enable payments</p>
          <p>Add <code className="bg-amber-100 px-1 rounded dark:bg-amber-500/20">STRIPE_SECRET_KEY</code>, <code className="bg-amber-100 px-1 rounded dark:bg-amber-500/20">STRIPE_WEBHOOK_SECRET</code>, <code className="bg-amber-100 px-1 rounded dark:bg-amber-500/20">STRIPE_PRO_PRICE_ID</code>, and <code className="bg-amber-100 px-1 rounded dark:bg-amber-500/20">STRIPE_ENTERPRISE_PRICE_ID</code> to <code className="bg-amber-100 px-1 rounded dark:bg-amber-500/20">server/.env</code>.</p>
        </div>
      )}
    </div>
  );
}
