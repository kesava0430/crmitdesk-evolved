import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '../api/client';
import { useAuth } from '../contexts/AuthContext';
import { PageHeader, Button, Modal, Badge, SearchInput, EmptyState, Spinner, SearchableSelect, RowActions } from '../shared/components';
import { Users, Plus, UserX, Pencil, Shield, Mail, Copy, Check, KeyRound } from 'lucide-react';
import { useFormat } from '../hooks/useFormat';
import { useRoles } from '../api/work';

/**
 * Role options come from the Role table, not a hardcoded list.
 *
 * The six legacy enum values used to be the only choices here, which meant a
 * role an admin created under Administration → Roles & Permissions — or any of
 * the built-in HR Manager / Finance / Executive roles — simply never appeared
 * when adding a user. Creating a role you could not then assign is worse than
 * not offering role creation at all.
 */
function useRoleOptions() {
  const { data, isLoading } = useRoles();
  const options = (data?.data ?? [])
    .filter(r => r.isActive)
    .map(r => ({
      value: r.id,
      label: r.description ? `${r.name} — ${r.description}` : r.name,
    }));
  return { options, isLoading, roles: data?.data ?? [] };
}

const ROLES = ['SUPER_ADMIN','CRM_MANAGER','SALES_REP','IT_MANAGER','IT_AGENT','EMPLOYEE'];
const roleVariant: Record<string, any> = {
  SUPER_ADMIN: 'red', CRM_MANAGER: 'purple', SALES_REP: 'blue',
  IT_MANAGER: 'orange', IT_AGENT: 'yellow', EMPLOYEE: 'gray',
};

function UserForm({ initial, onSubmit, loading }: any) {
  const { options: roleOptions, isLoading: rolesLoading, roles } = useRoleOptions();
  // An existing user may still be on the legacy enum with no Role row linked,
  // so fall back to matching by legacyRole rather than showing an empty picker.
  const initialRoleId =
    initial?.roleId ?? roles.find(r => r.legacyRole === initial?.role)?.id ?? '';
  const [form, setForm] = useState(
    initial
      ? { ...initial, roleId: initialRoleId }
      : { name: '', email: '', password: '', roleId: '', department: '', phone: '' }
  );
  const f = (k: string) => (e: any) => setForm((p: any) => ({ ...p, [k]: e.target.value }));
  return (
    <form
      onSubmit={e => {
        e.preventDefault();
        // Send roleId only. The server derives the legacy enum from the Role's
        // base access level, so passing a stale `role` alongside it would just
        // be a second source of truth to disagree with.
        const { role: _legacy, ...payload } = form;
        onSubmit(payload);
      }}
      className="space-y-3"
    >
      <div className="form-section">
        <p className="form-section-title">Account Details</p>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="form-label">Full Name <span className="req">*</span></label>
            <input aria-label="Full Name" required className="ui-input" value={form.name} onChange={f('name')} placeholder="Jane Smith" />
          </div>
          <div>
            <label className="form-label">Email <span className="req">*</span></label>
            <input aria-label="Email" required type="email" className="ui-input" value={form.email} onChange={f('email')} disabled={!!initial} placeholder="jane@company.com" />
          </div>
          {!initial && (
            <div>
              <label className="form-label">Password <span className="req">*</span></label>
              <input aria-label="Password" required type="password" minLength={8} className="ui-input" value={form.password} onChange={f('password')} placeholder="Min 8 characters" />
            </div>
          )}
          <div>
            <label className="form-label">Department</label>
            <input className="ui-input" value={form.department} onChange={f('department')} placeholder="e.g. Engineering, Sales" />
          </div>
          <div>
            <label className="form-label">Phone (WhatsApp)</label>
            <input aria-label="Phone" className="ui-input" value={form.phone || ''} onChange={f('phone')} placeholder="+14155551234" />
          </div>
        </div>
      </div>
      <div className="form-section">
        <p className="form-section-title">Permissions</p>
        <div>
          <label className="form-label">Role <span className="req">*</span></label>
          <SearchableSelect
            ariaLabel="Role"
            value={form.roleId || (initialRoleId ?? '')}
            onChange={val => setForm((p: any) => ({ ...p, roleId: val }))}
            required
            options={rolesLoading ? [{ value: '', label: 'Loading roles…' }] : roleOptions}
          />
          <p className="form-hint">
            Decides what this user can see and do. Manage the list under Administration → Roles &amp; Permissions.
          </p>
        </div>
      </div>
      <div className="flex justify-end pt-1">
        <Button type="submit" loading={loading}>{initial ? 'Save Changes' : 'Create User'}</Button>
      </div>
    </form>
  );
}

function InviteForm({ onSuccess }: { onSuccess: (link: string) => void }) {
  const { options: roleOptions, isLoading: rolesLoading } = useRoleOptions();
  const [form, setForm] = useState({ email: '', roleId: '' });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const res = await api.post('/admin/users/invite', form);
      onSuccess(res.data.link);
    } catch (err: any) {
      setError(err?.response?.data?.error || 'Failed to send invite');
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-3">
      {error && <div className="bg-red-50 dark:bg-red-500/10 border border-red-200 dark:border-red-500/30 text-red-700 dark:text-red-300 text-sm px-3 py-2.5 rounded-lg">{error}</div>}
      <div className="form-section">
        <p className="form-section-title">Invite Details</p>
        <div className="space-y-4">
          <div>
            <label className="form-label">Email address <span className="req">*</span></label>
            <input aria-label="Email" required type="email" className="ui-input" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} placeholder="colleague@company.com" />
          </div>
          <div>
            <label className="form-label">Role <span className="req">*</span></label>
            <SearchableSelect
              ariaLabel="Role"
              value={form.roleId}
              onChange={val => setForm(f => ({ ...f, roleId: val }))}
              required
              options={rolesLoading ? [{ value: '', label: 'Loading roles…' }] : roleOptions}
            />
            <p className="form-hint">
              The role is stored on the invite, so a custom role survives until the person accepts.
            </p>
          </div>
        </div>
      </div>
      <div className="flex justify-end pt-1">
        <Button type="submit" loading={loading} icon={<Mail size={14} />}>Generate Invite Link</Button>
      </div>
    </form>
  );
}

function CopyLink({ link }: { link: string }) {
  const [copied, setCopied] = useState(false);
  function copy() {
    navigator.clipboard.writeText(link).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  }
  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2 p-3 bg-green-50 dark:bg-green-500/10 border border-green-200 dark:border-green-500/30 rounded-lg">
        <Check size={16} className="text-green-600 dark:text-green-400 flex-shrink-0" />
        <span className="text-sm text-green-700 dark:text-green-300 font-medium">Invite link generated!</span>
      </div>
      <p className="text-sm text-fg-muted">Share this link with the invitee — it expires in 7 days:</p>
      <div className="flex gap-2">
        <input readOnly value={link} className="flex-1 text-xs border border-line rounded-lg px-3 py-2 bg-surface-sunken dark:text-gray-200 font-mono truncate" />
        <button onClick={copy} className="flex items-center gap-1 px-3 py-2 bg-brand-600 text-white text-xs rounded-lg hover:bg-brand-700 transition-colors flex-shrink-0">
          {copied ? <Check size={13} /> : <Copy size={13} />}
          {copied ? 'Copied!' : 'Copy'}
        </button>
      </div>
    </div>
  );
}

type ModalState = null | 'create' | 'invite' | { type: 'edit'; user: any };

export function UsersPage() {
  const { user: currentUser } = useAuth();
  const { date } = useFormat();
  const [search, setSearch] = useState('');
  const [modal, setModal] = useState<ModalState>(null);
  const [inviteLink, setInviteLink] = useState<string | null>(null);
  const qc = useQueryClient();

  const { data: users, isLoading } = useQuery({
    queryKey: ['admin-users'],
    queryFn: () => api.get('/admin/users').then(r => Array.isArray(r.data) ? r.data : r.data.data ?? []),
  });

  // Users with no employee record. Provisioning is automatic and non-throwing,
  // so this should normally be zero — when it isn't, it's a repairable state
  // rather than something to re-enter by hand.
  const unlinked = (users ?? []).filter((u: any) => !u.employee);

  const reconcile = useMutation({
    mutationFn: () => api.post('/admin/users/reconcile-employees?fix=true').then(r => r.data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin-users'] }),
  });

  const { data: invites } = useQuery({
    queryKey: ['admin-invites'],
    queryFn: () => api.get('/org/invites').then(r => r.data),
  });

  const create = useMutation({
    mutationFn: (data: any) => api.post('/admin/users', data).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['admin-users'] }); setModal(null); },
  });
  const update = useMutation({
    mutationFn: ({ id, ...data }: any) => api.patch(`/admin/users/${id}`, data).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['admin-users'] }); setModal(null); },
  });
  const deactivate = useMutation({
    mutationFn: (id: string) => api.delete(`/admin/users/${id}`).then(r => r.data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['admin-users'] }),
  });
  const resetPassword = useMutation({
    mutationFn: (id: string) => api.post(`/admin/users/${id}/reset-password`).then(r => r.data),
    onSuccess: (data: any) => alert(data?.message || 'Reset link sent.'),
    onError: (err: any) => alert(err?.response?.data?.error || 'Could not send reset link.'),
  });

  const filtered = users?.filter((u: any) =>
    !search || u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase())
  );

  const roleGroups = ROLES.reduce((acc: any, role) => {
    acc[role] = users?.filter((u: any) => u.role === role).length || 0;
    return acc;
  }, {});

  const pendingInvites = invites?.filter((i: any) => !i.usedAt && new Date(i.expiresAt) > new Date()) || [];

  function closeModal() {
    setModal(null);
    setInviteLink(null);
  }

  const BLOCKED_ROLES = ['SALES_REP', 'IT_AGENT', 'EMPLOYEE'];
  if (currentUser && BLOCKED_ROLES.includes(currentUser.role)) {
    return (
      <div className="p-8 text-center">
        <p className="text-red-600 dark:text-red-400 text-sm font-medium">Access denied. You don't have permission to view this page.</p>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-5 animate-slide-up">
      {/* Role summary */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
        {ROLES.map(role => (
          <div key={role} className="bg-surface border border-line rounded-xl p-3 text-center">
            <p className="text-xl font-bold text-fg">{roleGroups[role]}</p>
            <p className="text-xs text-fg-subtle mt-0.5">{role.replace(/_/g,' ')}</p>
          </div>
        ))}
      </div>

      <PageHeader
        title="Users"
        subtitle={`${filtered?.length ?? 0} users`}
        actions={<>
          <SearchInput value={search} onChange={setSearch} placeholder="Search users..." />
          <Button variant="secondary" icon={<Mail size={15} />} onClick={() => { setInviteLink(null); setModal('invite'); }}>Invite User</Button>
          <Button icon={<Plus size={15} />} onClick={() => setModal('create')}>Create User</Button>
        </>}
      />

      {/* Users with no employee record — one click to repair, never re-entry. */}
      {unlinked.length > 0 && (
        <div className="bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/30 rounded-xl p-4 flex items-center justify-between gap-3 flex-wrap">
          <div>
            <p className="text-sm font-semibold text-amber-800 dark:text-amber-300">
              {unlinked.length} user{unlinked.length === 1 ? '' : 's'} without an employee record
            </p>
            <p className="text-xs text-amber-700 dark:text-amber-400 mt-0.5">
              New users normally get one automatically. These predate that, or were created while HR was unavailable —
              creating them here takes a second and needs no re-typing.
            </p>
          </div>
          <Button
            variant="secondary"
            loading={reconcile.isPending}
            onClick={() => reconcile.mutate()}
          >
            Create {unlinked.length} employee record{unlinked.length === 1 ? '' : 's'}
          </Button>
        </div>
      )}

      {/* Pending Invites */}
      {pendingInvites.length > 0 && (
        <div className="bg-amber-50 dark:bg-amber-500/10 border border-amber-200 dark:border-amber-500/30 rounded-xl p-4">
          <p className="text-sm font-semibold text-amber-800 dark:text-amber-300 mb-2">Pending Invites ({pendingInvites.length})</p>
          <div className="space-y-1">
            {pendingInvites.map((inv: any) => (
              <div key={inv.id} className="flex items-center justify-between text-sm">
                <span className="text-amber-700 dark:text-amber-300">{inv.email}</span>
                <div className="flex items-center gap-2">
                  <Badge variant="yellow">{inv.role.replace(/_/g,' ')}</Badge>
                  <span className="text-xs text-amber-500 dark:text-amber-400">Expires {date(inv.expiresAt)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {isLoading ? <Spinner /> : filtered?.length === 0 ? (
        <EmptyState icon={<Users size={24} />} title="No users found" description="Invite or create team members to get started" action={{ label: 'Invite User', onClick: () => setModal('invite') }} />
      ) : (
        <div className="bg-surface rounded-xl border border-line-subtle shadow-sm p-5">
          <div className="table-container">
          <table className="w-full text-sm min-w-[640px]">
            <thead><tr className="bg-surface-sunken border-b border-line-subtle">
              <th className="text-left px-4 py-3 text-xs font-semibold text-fg-muted uppercase tracking-wider">User</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-fg-muted uppercase tracking-wider">Role</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-fg-muted uppercase tracking-wider">Department</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-fg-muted uppercase tracking-wider">Employee</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-fg-muted uppercase tracking-wider hidden sm:table-cell">Last Login</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-fg-muted uppercase tracking-wider hidden sm:table-cell">Created At</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-fg-muted uppercase tracking-wider">Status</th>
              <th className="text-left px-4 py-3 text-xs font-semibold text-fg-muted uppercase tracking-wider">Actions</th>
            </tr></thead>
            <tbody className="divide-y divide-line-subtle">
              {filtered?.map((u: any) => (
                <tr key={u.id} className="hover:bg-surface-hover transition-colors group">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-full bg-brand-100 text-brand-600 flex items-center justify-center text-sm font-bold flex-shrink-0">
                        {u.name[0]?.toUpperCase()}
                      </div>
                      <div>
                        <p className="font-medium text-fg">{u.name}</p>
                        <p className="text-xs text-fg-subtle">{u.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    {/* Show the assigned Role's name when there is one — a
                        custom role like "Regional Sales Head" is far more
                        useful here than the base access level it maps to.
                        Users still on the legacy enum fall back to it. */}
                    <Badge variant={roleVariant[u.role] || 'gray'}>
                      {u.roleRef?.name ?? u.role.replace(/_/g, ' ')}
                    </Badge>
                  </td>
                  <td className="px-4 py-3 text-fg-muted">{u.department || '—'}</td>
                  {/* Adding a user creates their employee record automatically, so
                      this should read as a code for everyone. "Not linked" means
                      provisioning was skipped or failed — use "Fix employee
                      records" above to repair it. */}
                  <td className="px-4 py-3">
                    {u.employee ? (
                      <span className="text-xs font-mono text-fg-muted">{u.employee.employeeCode}</span>
                    ) : (
                      <Badge variant="orange">Not linked</Badge>
                    )}
                  </td>
                  <td className="px-4 py-3 hidden sm:table-cell text-fg-subtle">—</td>
                  <td className="px-4 py-3 hidden sm:table-cell text-fg-subtle">
                    {u.createdAt ? date(u.createdAt) : '—'}
                  </td>
                  <td className="px-4 py-3">
                    <Badge variant={u.isActive ? 'green' : 'gray'}>{u.isActive ? 'Active' : 'Inactive'}</Badge>
                  </td>
                  <td className="px-4 py-3">
                    <RowActions items={[
                      { label: 'Edit', icon: <Pencil size={14} />, onClick: () => setModal({ type: 'edit', user: u }) },
                      { label: 'Reset Password', icon: <KeyRound size={14} />, onClick: () => resetPassword.mutate(u.id), hidden: !u.isActive },
                      { label: 'Deactivate', icon: <UserX size={14} />, onClick: () => deactivate.mutate(u.id), variant: 'danger', hidden: !u.isActive },
                      { label: 'Reactivate', icon: <Shield size={14} />, onClick: () => update.mutate({ id: u.id, isActive: true }), hidden: u.isActive },
                    ]} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          </div>
        </div>
      )}

      {/* Create User Modal */}
      <Modal open={modal === 'create'} onClose={closeModal} title="Create User">
        <UserForm
          loading={create.isPending}
          onSubmit={(form: any) => create.mutate(form)}
        />
      </Modal>

      {/* Edit User Modal */}
      <Modal open={!!(modal && typeof modal === 'object' && modal.type === 'edit')} onClose={closeModal} title="Edit User">
        <UserForm
          initial={modal && typeof modal === 'object' && modal.type === 'edit' ? modal.user : null}
          loading={update.isPending}
          onSubmit={(form: any) => {
            if (modal && typeof modal === 'object' && modal.type === 'edit') {
              update.mutate({ id: modal.user.id, ...form });
            }
          }}
        />
      </Modal>

      {/* Invite User Modal */}
      <Modal open={modal === 'invite'} onClose={closeModal} title="Invite Team Member">
        {inviteLink ? (
          <CopyLink link={inviteLink} />
        ) : (
          <InviteForm onSuccess={(link) => {
            setInviteLink(link);
            qc.invalidateQueries({ queryKey: ['admin-invites'] });
          }} />
        )}
      </Modal>

    </div>
  );
}
