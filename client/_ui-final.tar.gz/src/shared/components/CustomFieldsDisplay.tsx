import { useCustomFieldDefs, useCustomFieldValues, fromValueRecords } from '../../api/customFields';
import { useContacts } from '../../api/crm';
import { Card } from './Card';

interface Props {
  entityType: string;
  entityId: string;
  /** Wrap in the standard bordered white card used by sibling detail-page sections. */
  card?: boolean;
}

function displayValue(fieldType: string, raw: string | undefined, contactNameById?: Map<string, string>) {
  if (raw === undefined || raw === '') return '--';
  if (fieldType === 'BOOLEAN') return raw === 'true' ? 'Yes' : raw === 'false' ? 'No' : '--';
  // REFERENCE stores the linked Contact's id — resolve it to a name rather
  // than showing the raw id (see customfields.controller.ts's FIELD_TYPES
  // comment on why REFERENCE always points at Contact today).
  if (fieldType === 'REFERENCE') return contactNameById?.get(raw) || '--';
  return raw;
}

/** Read-only custom field values for an entity detail view (e.g. Contact detail page). */
export function CustomFieldsDisplay({ entityType, entityId, card }: Props) {
  const { data: defs } = useCustomFieldDefs(entityType);
  const { data: records } = useCustomFieldValues(entityId);
  const hasReferenceField = !!defs?.some(d => d.fieldType === 'REFERENCE');
  const { data: contacts } = useContacts(undefined, hasReferenceField);
  // Explicit <string, string> on the constructor itself — relying on
  // inference from the .map() callback's return type wasn't enough (still
  // widened to Map<unknown, unknown> and failed the build), since `contacts`
  // comes back untyped (any) from useContacts, so give the Map its type
  // directly instead of hoping TS infers it from the array.
  const contactNameById = new Map<string, string>((contacts ?? []).map((c: any) => [c.id, c.name]));
  const valueMap = fromValueRecords(records);

  if (!defs || defs.length === 0) return null;

  const grid = (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
      {defs.map(def => (
        <Card key={def.id} padding="sm" tone="sunken" flat>
          <p className="text-fg-subtle text-xs mb-1">{def.label}</p>
          <p className="font-medium text-fg">{displayValue(def.fieldType, valueMap[def.fieldKey], contactNameById)}</p>
        </Card>
      ))}
    </div>
  );

  if (!card) return grid;

  return (
    <Card>
      <p className="text-sm font-medium text-fg mb-3">Custom Fields</p>
      {grid}
    </Card>
  );
}
